-- @Author              : GGELUA
-- @Last Modified by    : baidwwy
-- @Date                : 2022-08-28 19:47:41
-- @Last Modified time  : 2022-08-29 03:09:45
return {
    名称='',
    获得时间 = 0
}