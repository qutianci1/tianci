-- @Author              : GGELUA
-- @Last Modified by    : baidwwy
-- @Date                : 2022-08-28 19:46:29
-- @Last Modified time  : 2022-08-29 08:46:11
return {
    名称 = '',
    数量 = 1,
    叠加 = 0,
    获得时间 = 0,
    丢弃时间 = 0,
    位置 = 0
}
