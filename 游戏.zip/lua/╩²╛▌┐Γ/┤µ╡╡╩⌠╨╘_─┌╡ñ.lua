-- @Author              : GGELUA
-- @Last Modified by    : GGELUA2
-- @Date                : 2022-08-29 12:09:09
-- @Last Modified time  : 2023-05-03 05:39:14

return {
    名称 = '',
    等级 = 1,
    经验 = 0,
    元气 = 6000,
    最大元气 = 6000,
    转生 = 0,
    点化 = 0,
    技能 = ''
}
