-- @Author              : GGELUA
-- @Last Modified by    : baidwwy
-- @Date                : 2022-07-13 08:54:32
-- @Last Modified time  : 2024-08-01 09:23:56

return {
    外形 = 4001,
    名称 = '',
    名称颜色 = 0,
    等级 = 0,
    耐力 = 0,
    最大耐力 = 0,
    经验 = 0,
    最大经验 = 0,
    是否观看 = false,
    是否选中 = false
}
