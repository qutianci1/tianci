-- @Author              : GGELUA
-- @Last Modified by    : GGELUA2
-- @Date                : 2022-08-28 19:46:59
-- @Last Modified time  : 2023-04-13 00:11:01
return {
    好友列表 = {},
}