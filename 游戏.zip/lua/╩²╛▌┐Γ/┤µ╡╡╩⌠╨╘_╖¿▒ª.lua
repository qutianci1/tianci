-- @Author              : GGELUA
-- @Last Modified by    : GGELUA2
-- @Date                : 2022-08-28 19:46:59
-- @Last Modified time  : 2023-09-14 22:13:31
return {
    名称 = '',
    主人 = '',
    阴阳 = '',
    灵气 = 0,
    灵气上限 = 600,
    道行 = 0,
    升级道行 = 0,
    等级 = 1,
    参战 = 0
}