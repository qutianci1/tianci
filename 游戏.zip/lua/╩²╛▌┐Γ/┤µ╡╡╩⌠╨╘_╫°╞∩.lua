-- @Author              : GGELUA
-- @Last Modified by    : baidwwy
-- @Date                : 2022-08-28 19:48:02
-- @Last Modified time  : 2022-08-28 19:48:02
return {

    名称 = '',
    等级 = 0,
    几座 = 0,
    种族 = 0,
    体力 = 0,
    最大体力 = 0,
    经验 = 0,
    最大经验 = 0,
    灵性 = 0,
    力量 = 0,
    根骨 = 0,
    初灵 = 0,
    初力 = 0,
    初根 = 0,
    管制 = {},
    技能 = {},
    是否乘骑 = false
}
