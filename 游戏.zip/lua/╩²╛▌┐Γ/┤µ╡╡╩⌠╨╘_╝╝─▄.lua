-- @Author              : GGELUA
-- @Last Modified by    : baidwwy
-- @Date                : 2022-08-28 19:47:14
-- @Last Modified time  : 2022-09-01 16:49:32
return {
    名称 = '',
    熟练度 = 1
}
